/**
 * A deliberately small slice of the Vercel REST API.
 *
 * The CLI cannot be shelled out to from a serverless function, so provisioning
 * talks to the API directly.
 *
 * Only the calls needed to stand a site up are here, and nothing destructive is
 * exposed. A Vercel token is scoped to an account or a team and never to a
 * single project, so the token behind this can reach every project on the
 * account — including ones that have nothing to do with these sites. Adding a
 * delete here would put those one bug away from being removed.
 */

const API = "https://api.vercel.com";

export interface VercelProject {
  createdAt?: number;
  framework?: string | null;
  id: string;
  /** Git repository the project deploys from, when it has one. */
  link?: { org?: string; repo?: string; type?: string } | null;
  name: string;
}

/**
 * The repository whose projects this application manages.
 *
 * Every site is a deployment of this same repo, so the repo is what separates
 * "a site" from the unrelated projects that share the account. Resolved from
 * the environment rather than hardcoded so a fork does not have to edit code.
 */
export const managedRepo = (): string | null => {
  const explicit = process.env.SITES_REPO?.trim();
  if (explicit) {
    return explicit;
  }
  const owner = process.env.VERCEL_GIT_REPO_OWNER?.trim();
  const slug = process.env.VERCEL_GIT_REPO_SLUG?.trim();
  return owner && slug ? `${owner}/${slug}` : null;
};

/** True when a project deploys from the repository this app manages. */
export const isManagedProject = (
  project: VercelProject,
  repo: string
): boolean => {
  const { link } = project;
  if (!(link?.org && link.repo)) {
    return false;
  }
  return `${link.org}/${link.repo}`.toLowerCase() === repo.toLowerCase();
};

export interface EnvVar {
  key: string;
  /** Vercel's own naming: which environments the value applies to. */
  target: ("production" | "preview" | "development")[];
  value: string;
}

const token = (): string | null => process.env.VERCEL_TOKEN?.trim() || null;

export const isVercelConfigured = (): boolean => token() !== null;

/** Team scope, when the sites live under a team rather than a personal account. */
const teamId = (): string | null => process.env.VERCEL_TEAM_ID?.trim() || null;

const request = async <T>(
  path: string,
  init?: { body?: unknown; method?: string }
): Promise<T> => {
  const key = token();
  if (!key) {
    throw new Error("VERCEL_TOKEN is not set");
  }

  // Built with URL so the team scope appends correctly whether or not the path
  // already carries a query string.
  const url = new URL(path, API);
  const team = teamId();
  if (team) {
    url.searchParams.set("teamId", team);
  }

  const res = await fetch(url, {
    body: init?.body === undefined ? undefined : JSON.stringify(init.body),
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
    },
    method: init?.method ?? "GET",
  });

  const json = (await res.json().catch(() => ({}))) as T & {
    error?: { message?: string };
  };
  if (!res.ok) {
    throw new Error(
      json.error?.message ?? `Vercel API request failed (${res.status})`
    );
  }
  return json;
};

export const listProjects = async (): Promise<VercelProject[]> => {
  const data = await request<{ projects: VercelProject[] }>(
    "/v9/projects?limit=100"
  );
  return data.projects;
};

/**
 * Creates a project wired to the same repository this site is built from.
 *
 * A new portfolio is the same codebase with a different SITE, so it is deployed
 * from the same repo rather than a copy — which is what keeps every site fixed
 * by one change rather than one per site.
 */
export const createProject = async (input: {
  name: string;
  repo: string;
}): Promise<VercelProject> =>
  await request<VercelProject>("/v11/projects", {
    body: {
      framework: "vite",
      gitRepository: { repo: input.repo, type: "github" },
      name: input.name,
    },
    method: "POST",
  });

export const setEnvVars = async (
  projectId: string,
  vars: EnvVar[]
): Promise<void> => {
  await request(
    `/v10/projects/${encodeURIComponent(projectId)}/env?upsert=true`,
    {
      body: vars.map((v) => ({
        key: v.key,
        target: v.target,
        type: "encrypted",
        value: v.value,
      })),
      method: "POST",
    }
  );
};

export const addDomain = async (
  projectId: string,
  domain: string
): Promise<void> => {
  await request(`/v10/projects/${encodeURIComponent(projectId)}/domains`, {
    body: { name: domain },
    method: "POST",
  });
};

export interface BlobStore {
  id: string;
  name: string;
}

/**
 * Creates a Blob store.
 *
 * Databases cannot be created the same way: Vercel Postgres was retired and its
 * endpoint now answers 410, and its Neon replacement is a marketplace
 * integration with no create-via-API path. So storage provisioning stops here,
 * and the connection string has to come from outside.
 */
export const createBlobStore = async (name: string): Promise<BlobStore> => {
  const data = await request<{ store: BlobStore }>("/v1/storage/stores/blob", {
    body: { name },
    method: "POST",
  });
  return data.store;
};

/**
 * Connects a store to a project, which is what makes Vercel inject its
 * credentials — BLOB_READ_WRITE_TOKEN is created by the connection rather than
 * being something to set by hand.
 */
export const connectStore = async (
  storeId: string,
  projectId: string
): Promise<void> => {
  await request(
    `/v1/storage/stores/${encodeURIComponent(storeId)}/connections`,
    { body: { projectId }, method: "POST" }
  );
};

export const listProjectEnvKeys = async (
  projectId: string
): Promise<string[]> => {
  const data = await request<{ envs: { key: string }[] }>(
    `/v9/projects/${encodeURIComponent(projectId)}/env`
  );
  return data.envs.map((e) => e.key);
};

export interface StoreSummary {
  id: string;
  name: string;
  type?: string;
}

/** Every store on the account, used to reuse one rather than fail on its name. */
export const listStores = async (): Promise<StoreSummary[]> => {
  const data = await request<{ stores: StoreSummary[] }>(
    "/v1/storage/stores?limit=100"
  );
  return data.stores ?? [];
};

/**
 * Authorises a marketplace purchase, returning the id the store creation needs.
 *
 * Marketplace resources are billed products, so Vercel requires an explicit
 * authorization even on the free plan. Note metadata is sent as a JSON *string*
 * here while the store call below takes an object — the two endpoints genuinely
 * disagree.
 */
const authorizeMarketplacePurchase = async (input: {
  billingPlanId: string;
  configurationId: string;
  region: string;
}): Promise<string> => {
  const data = await request<{ authorization: { id: string } }>(
    "/v1/integrations/billing/authorization",
    {
      body: {
        billingPlanId: input.billingPlanId,
        integrationConfigurationId: input.configurationId,
        integrationIdOrSlug: "neon",
        integrationProductIdOrSlug: "neon",
        metadata: JSON.stringify({ region: input.region }),
      },
      method: "POST",
    }
  );
  return data.authorization.id;
};

/**
 * Creates a Neon database through the Vercel marketplace integration.
 *
 * Not the same mechanism as a Blob store. Vercel's own Postgres was retired and
 * its endpoint answers 410; databases are now marketplace resources, which take
 * three calls: authorise the purchase, create the store, then connect it to a
 * project. The configuration belongs to a team, so VERCEL_TEAM_ID is required
 * for this even though the rest of the API works without one.
 */
export const createNeonDatabase = async (input: {
  billingPlanId?: string;
  configurationId: string;
  name: string;
  region?: string;
}): Promise<{ id: string; name: string }> => {
  // Free unless asked otherwise: provisioning should not start billing as a
  // side effect of creating a site.
  const billingPlanId = input.billingPlanId ?? "free_v3";
  const region = input.region ?? "iad1";

  const authorizationId = await authorizeMarketplacePurchase({
    billingPlanId,
    configurationId: input.configurationId,
    region,
  });

  const data = await request<{ store: { id: string; name: string } }>(
    "/v1/storage/stores/integration",
    {
      body: {
        authorizationId,
        billingPlanId,
        integrationConfigurationId: input.configurationId,
        integrationProductIdOrSlug: "neon",
        metadata: { region },
        name: input.name,
      },
      method: "POST",
    }
  );
  return data.store;
};

/** The installed Neon integration, if there is one. */
export const neonConfigurationId = async (): Promise<string | null> => {
  const data = await request<
    | { id: string; slug: string }[]
    | { configurations: { id: string; slug: string }[] }
  >("/v1/integrations/configurations?view=account");
  const items = Array.isArray(data) ? data : data.configurations;
  return items.find((c) => c.slug === "neon")?.id ?? null;
};
