import { containedBy } from "../../config/graph.js";
import { DEFAULT_PLACEHOLDER } from "../../config/nodes/iterate.js";
import { HEX_COLOUR } from "../../config/nodes/palette.js";
import { renderedUrlOf } from "../../config/nodes/rendered.js";
import type { BoardItem, BoardItemVariation, BoardWire } from "../types";
import { parseItems } from "./listItems";

/**
 * Drag-and-drop type for an image pulled off a node.
 *
 * Board-specific so the canvas can tell it apart from a file dropped in from
 * the desktop, which is a different act with a different cost — one uploads,
 * the other already lives in our own storage and only needs pinning.
 */
export const BOARD_IMAGE_TYPE = "application/x-board-image";

/**
 * What an item shows, and what it hands down a wire.
 *
 * Shared rather than kept inside the node view, because two places now need it
 * — the node draws its gallery, and the canvas resolves what a wire is carrying
 * — and the fallback chain below is exactly the sort of thing that goes wrong
 * when it is written twice. It already did once: a node that read only the
 * newest shape stranded every result saved before that shape existed.
 */

/**
 * Every image a node has to show, newest shape first.
 *
 * `history` is everything it has made. `variations` covers a run that finished
 * before history existed, and the bare `url` covers results saved before either
 * did — an image already paid for should never be stranded in the database
 * because the shape around it moved on.
 */
export const pickImages = (
  stored: BoardItem["result"]
): BoardItemVariation[] => {
  if (stored?.history?.length) {
    return stored.history;
  }
  if (stored?.variations?.length) {
    return stored.variations;
  }
  return stored?.url ? [stored as BoardItemVariation] : [];
};

/** Which stored version the node is showing; the first until one is picked. */
export const selectedIndex = (config: Record<string, unknown>): number =>
  typeof config.selectedVersion === "number" ? config.selectedVersion : 0;

/**
 * The words this item sends downstream, or null if it sends none.
 *
 * Mirrors singleOutputOf on the server, which is the authority — this exists so
 * a node can *show* what is arriving on its prompt rather than merely saying
 * that something is. A wire you cannot read is a wire you have to trust.
 */
/** A chain of Combine nodes longer than this is a mistake, not a design. */
const MAX_JOIN_DEPTH = 8;

/**
 * Every prompt an Iterate node describes.
 *
 * Mirrors iteratedOutputsOf on the server, which is the authority. This exists
 * so the node can show what it will send before anything is run.
 */
export const iteratedTextOf = (
  item: BoardItem,
  graph: { items: BoardItem[]; wires: BoardWire[] },
  depth = 0
): string[] => {
  if (depth > MAX_JOIN_DEPTH) {
    return [];
  }
  /** Each wire kept apart, because each wire fills its own slot. */
  /**
   * Each wire kept apart, because each wire fills its own slot.
   *
   * `single` is for the ports that hold one value — the template, and the line
   * appended to each prompt. A wire can carry several, and running them all
   * together into a single field produced a suffix five colors long stuck onto
   * every prompt.
   */
  const readPerWire = (port: string, single = false): string[] =>
    graph.wires
      .filter((w) => w.targetItemId === item.id && w.targetPort === port)
      .map((w) => graph.items.find((i) => i.id === w.sourceItemId))
      .map((source) => {
        const sent = outputListOf(source ?? null, graph, depth + 1);
        return single ? (sent[0] ?? "") : sent.join("\n");
      })
      .filter((text) => text.trim());

  const config = item.config ?? {};
  const typedTemplate =
    typeof config.template === "string" ? config.template.trim() : "";
  const template = readPerWire("template", true).at(-1) ?? typedTemplate;
  if (!template) {
    return [];
  }
  const raw = config.placeholder;
  const placeholder =
    typeof raw === "string" && raw.trim() ? raw.trim() : DEFAULT_PLACEHOLDER;

  const wiredLists = readPerWire("values");
  const typedList =
    typeof config.values === "string" && config.values.trim()
      ? [config.values]
      : [];
  const slots = template.split(placeholder).length - 1;
  const lists =
    wiredLists.length > 0
      ? // One wire per slot: the list on the first wire fills the first {}.
        wiredLists
          .map((wired) => splitValues(wired, config.split))
          .filter((list) => list.length > 0)
      : columnsOf(typedList[0] ?? "", slots, config.split);

  // Appended per prompt rather than once for all of them. A Palette node
  // sending one color at a time carries a list, and the point of that list is
  // that each prompt gets a different one — a single suffix repeated would be
  // the "together" mode with extra steps. A shorter list cycles, as everywhere
  // else here.
  const suffixes = readPerWire("suffix");
  const prompts = expandTemplate(template, placeholder, lists);
  if (suffixes.length === 0) {
    return prompts;
  }
  const parts = suffixes
    .flatMap((text) => text.split(LINES))
    .filter((t) => t.trim());
  return prompts.map(
    (prompt, row) => `${prompt}, ${parts[row % parts.length]?.trim() ?? ""}`
  );
};

/**
 * Everything an item sends, which is not always one thing.
 *
 * Mirrors outputsOf on the server. Two nodes are plural by design — an Iterate
 * node writes a prompt per value, and a Palette node set to send one color at
 * a time sends one per swatch — and every reader has to account for that or it
 * silently keeps only the first.
 */
export const outputListOf = (
  item: BoardItem | null,
  graph: { items: BoardItem[]; wires: BoardWire[] },
  depth = 0
): string[] => {
  if (!item) {
    return [];
  }
  if (item.nodeType === "iterate") {
    return iteratedTextOf(item, graph, depth);
  }
  if (item.nodeType === "list") {
    return parseItems(item.config?.items);
  }
  if (item.nodeType === "palette") {
    return paletteOutputsOf(item.config ?? {});
  }
  const single = outputTextOf(item, graph, depth);
  return single ? [single] : [];
};

/** Mirrors expandTemplate on the server, which is the authority. */
const expandTemplate = (
  template: string,
  placeholder: string,
  lists: string[][]
): string[] => {
  const parts = template.split(placeholder);
  if (parts.length - 1 === 0 || lists.length === 0) {
    return [template];
  }
  const rows = Math.max(...lists.map((list) => list.length));
  return Array.from({ length: rows }, (_, row) =>
    parts.reduce((text, part, index) => {
      if (index === 0) {
        return part;
      }
      const list = lists[Math.min(index - 1, lists.length - 1)] ?? [];
      return text + (list[row % list.length] ?? "") + part;
    }, "")
  );
};

/**
 * The typed Values field, read as one list per slot.
 *
 * With a single placeholder it is simply a list. With several, each line is one
 * row and the commas within it are its columns — "Orange, Brainstorm" on one
 * line fills both slots of that prompt. Typing pairs as pairs is how anyone would
 * write them down, and it is the only way the typed field can feed more than
 * one slot without growing a field per slot.
 */
const columnsOf = (raw: string, slots: number, mode: unknown): string[][] => {
  if (!raw.trim()) {
    return [];
  }
  if (slots <= 1) {
    const list = splitValues(raw, mode);
    return list.length > 0 ? [list] : [];
  }
  const rows = raw
    .split(LINES)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => line.split(",").map((cell) => cell.trim()));
  return Array.from({ length: slots }, (_, column) =>
    rows.map((cells) => cells[column] ?? cells.at(-1) ?? "").filter(Boolean)
  ).filter((list) => list.length > 0);
};

const LINES = /\r?\n/;

const splitValues = (raw: string, mode: unknown): string[] => {
  if (mode === "whole") {
    return [raw.trim()].filter(Boolean);
  }
  const parts = mode === "commas" ? raw.split(",") : raw.split(LINES);
  return parts.map((part) => part.trim()).filter(Boolean);
};

/**
 * A palette node's line, mirroring paletteTextOf on the server.
 *
 * The hex codes are written into the sentence deliberately: it reads as English
 * for the models that can only be asked, and Ideogram v3 has the codes lifted
 * back out into a real palette parameter.
 */
/**
 * What a palette sends: one constraint, or one color at a time.
 *
 * Mirrors paletteOutputsOf on the server.
 */
export const paletteOutputsOf = (config: Record<string, unknown>): string[] => {
  if (config.output !== "one at a time") {
    const line = paletteTextOf(config);
    return line ? [line] : [];
  }
  const raw = typeof config.colors === "string" ? config.colors : "";
  const strict = config.strictness === "mostly" ? "predominantly" : "only";
  // Each color as an instruction rather than as a bare code. "#5ccde9" on the
  // end of a prompt is a string a model has to guess the meaning of; "using
  // only this color: #5ccde9" says what to do with it, and reads the same way
  // as the together form so switching between them changes the number of
  // prompts rather than their grammar.
  return (raw.match(HEX_COLOUR) ?? []).map(
    (hex) => `using ${strict} this color: ${hex}`
  );
};

export const paletteTextOf = (
  config: Record<string, unknown>
): string | null => {
  const raw = typeof config.colors === "string" ? config.colors : "";
  const colors = raw.match(HEX_COLOUR);
  if (!colors || colors.length === 0) {
    return null;
  }
  const strict = config.strictness === "mostly" ? "predominantly" : "only";
  return `using ${strict} these colors: ${colors.join(", ")}`;
};

export const outputTextOf = (
  item: BoardItem | null,
  /** Needed only to resolve a Combine node, whose value is its inputs. */
  graph?: { items: BoardItem[]; wires: BoardWire[] },
  depth = 0
): string | null => {
  if (!item) {
    return null;
  }
  // Mirrors singleOutputOf on the server. Duplicated deliberately: the server
  // is the authority on what actually runs, and this exists so the canvas can
  // *show* the same answer without asking it.
  if (item.nodeType === "join" && graph && depth <= MAX_JOIN_DEPTH) {
    const parts = graph.wires
      .filter((w) => w.targetItemId === item.id && w.targetPort === "text")
      .map((w) => graph.items.find((i) => i.id === w.sourceItemId))
      .map((source) => (source ? outputTextOf(source, graph, depth + 1) : null))
      .filter((part): part is string => Boolean(part?.trim()));
    if (parts.length === 0) {
      return null;
    }
    const separator = item.config?.separator;
    return parts.join(typeof separator === "string" ? separator : ", ");
  }
  if (item.nodeType === "palette") {
    return paletteTextOf(item.config ?? {});
  }
  if (item.kind === "note" || item.kind === "text") {
    return item.body?.trim() || null;
  }
  if (item.kind !== "op") {
    return null;
  }
  // A produced description, when the node ran and made words.
  const produced = item.result?.text;
  if (typeof produced === "string" && produced.trim()) {
    return produced;
  }
  // A source node holds its value in settings and never runs, so there is no
  // result to read — a Prompt node keeps it under `text`, the others `prompt`.
  const config = item.config ?? {};
  const typed = config.text ?? config.prompt;
  return typeof typed === "string" && typed.trim() ? typed : null;
};

/**
 * The single image this item sends downstream, or null if it has none yet.
 *
 * A generated node offers the version currently chosen on it, so picking a
 * different one in the gallery re-styles whatever it feeds without any further
 * action — the selection is the answer to "which of these did you mean", and it
 * should mean the same thing everywhere. Mirrors what the run endpoint does
 * server-side when it resolves an upstream node's output.
 */
/**
 * Every picture an item hands downstream, not just the first.
 *
 * The plural counterpart to outputImageOf, and the reason a Batch node can show
 * what it is about to process. A frame contributes all of its pictures; a node
 * contributes the version currently chosen on it; a Batch contributes whatever
 * is wired into it, which is what makes them nestable.
 *
 * Mirrors outputsOf on the server, which remains the authority — this exists so
 * the canvas can show the batch before anything is spent on it.
 */
/**
 * The pictures struck off a Batch node.
 *
 * Kept as addresses rather than positions: a batch is resolved fresh every
 * time, so an index would come to mean a different picture the moment anything
 * upstream moved, and a run would quietly skip the wrong one.
 */
export const excludedFrom = (config: unknown): Set<string> => {
  const raw = (config as { excluded?: unknown } | null)?.excluded;
  return new Set(
    Array.isArray(raw)
      ? raw.filter((u): u is string => typeof u === "string")
      : []
  );
};

export const outputImagesOf = (
  item: BoardItem | null,
  graph: { items: BoardItem[]; wires: BoardWire[] },
  depth = 0
): string[] => {
  if (!item || depth > MAX_JOIN_DEPTH) {
    return [];
  }
  if (item.kind === "frame") {
    return containedBy(item, graph.items)
      .sort((a, b) => a.z - b.z)
      .flatMap((inside) => outputImagesOf(inside, graph, depth + 1));
  }
  if (item.nodeType === "batch") {
    const all = graph.wires
      .filter((w) => w.targetItemId === item.id && w.targetPort === "image")
      .flatMap((w) =>
        outputImagesOf(
          graph.items.find((i) => i.id === w.sourceItemId) ?? null,
          graph,
          depth + 1
        )
      );
    const kept = all.filter((url) => !excludedFrom(item.config).has(url));
    const raw = Number(item.config?.limit);
    const limit = Number.isFinite(raw) ? Math.trunc(raw) : 0;
    return limit > 0 ? kept.slice(0, limit) : kept;
  }
  const one = outputImageOf(item, graph.items);
  return one ? [one] : [];
};

/**
 * The picture an item currently *is*, rather than the one it arrived as.
 *
 * A tool reads the newest version as its input and writes the next one to
 * `result`, so anything that only ever reads `imageUrl` sees the original for
 * ever. ItemMedia learned this when Rotate and Edit both ran, both stored a new
 * picture, and both looked like they had done nothing — and the wires did not
 * learn it with it: an edited photograph drew correctly on the canvas and still
 * handed its untouched original to whatever it fed.
 *
 * One definition now, read by the canvas and by the wires, because the two
 * disagreeing is precisely the failure.
 */
export const currentImageUrl = (item: BoardItem): string | null =>
  item.result?.url ?? item.imageUrl ?? null;

export const outputImageOf = (
  item: BoardItem,
  /**
   * The board, needed only to resolve a frame.
   *
   * A frame's output is computed from geometry rather than stored, so it
   * cannot be answered from the item alone. Optional because every other kind
   * can — and because a caller that has no frame to resolve should not have to
   * hand over the whole board to ask about a photograph.
   */
  items: BoardItem[] = []
): string | null => {
  if (item.kind === "photo" || item.kind === "reference") {
    return currentImageUrl(item);
  }
  if (item.kind === "frame") {
    // The topmost picture on the frame, as a stand-in for all of them. The
    // wire really carries every one — the run fans out over the lot — but a
    // preview shows one thing, and showing nothing made a correctly wired
    // frame look like a node that could not see its own input.
    const inside = containedBy(item, items)
      .filter((contained) => currentImageUrl(contained))
      .sort((a, b) => b.z - a.z);
    return inside[0] ? currentImageUrl(inside[0]) : null;
  }
  if (item.kind !== "op") {
    return null;
  }
  // An element hands over its key image, which is stored on the node so the
  // canvas can draw it and resolve it without asking the library. The run
  // endpoint re-reads it from the elements table, which stays the authority on
  // what is actually sent — see withElements in api/boards/[id]/run.ts.
  if (item.nodeType === "element") {
    const stored = item.config?.imageUrl;
    return typeof stored === "string" && stored ? stored : null;
  }
  // A browser-rendered node's fresh render counts as its output before the
  // run has stored it, for the reason config/nodes/rendered.ts gives: the
  // next node's flush reads it in the same pass.
  const rendered = renderedUrlOf(item.nodeType, item.config);
  if (rendered) {
    return rendered;
  }
  const images = pickImages(item.result).filter((image) => Boolean(image?.url));
  if (images.length === 0) {
    return null;
  }
  const chosen = images[selectedIndex(item.config ?? {})] ?? images[0];
  return chosen?.url ?? null;
};
