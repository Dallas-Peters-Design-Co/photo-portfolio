import { HugeiconsIcon } from "@hugeicons/react";
import {
  Album02Icon,
  ArrowDown01Icon,
  ArrowUp01Icon,
  CopyIcon,
  Download01Icon,
  FrameIcon,
  GridIcon,
  Image01Icon,
  MagicWand01Icon,
  PenTool01Icon,
  RepeatIcon,
  SparklesIcon,
} from "@hugeicons-pro/core-stroke-standard";
import type { BoardItem, BoardWire } from "../../types";
import { useFrameActions } from "../FrameOpenContext";
import { isSvgUrl } from "../io/affinity";
import { frameSummary } from "../io/copyToBoard";
import { downloadImage } from "../io/downloadImage";
import { PrintRow } from "./PrintRow";
import { outputImageOf, outputImagesOf } from "../itemOutput";
import type { CanvasMenuTarget } from "./CanvasMenu";
import { CollectionRow, hasTools, ToolsRow } from "./CanvasMenuPanels";
import "../boardChrome.css";
import { useVectorEditorName } from "../hooks/useVectorEditorName";

/**
 * Every row the canvas menu can offer, and the rules for which apply.
 *
 * Split out of CanvasMenu.tsx, which had grown past the 500-line limit and needs
 * room for a "Save as recipe" row. The division is deliberate: CanvasMenu is
 * where the menu *is* — placement against the pointer, dismissal, the naming
 * step — and this is what it *contains*.
 *
 * Each row is its own component rather than a branch in one list, because what
 * makes a row applicable differs per row: a node that has produced something can
 * be downloaded, an SVG can be opened in the desktop editor, a raster can be
 * vectorised,
 * and a frame can be arranged. Written as one list those conditions collapse
 * into a chain nobody can read.
 */

/** How many pictures a node is holding, across every run it remembers. */
const countResults = (item: BoardItem): number => {
  const result = item.result as
    | { url?: string; variations?: unknown[] }
    | null
    | undefined;
  if (!result) {
    return 0;
  }
  if (Array.isArray(result.variations)) {
    return result.variations.filter(Boolean).length;
  }
  return result.url ? 1 : 0;
};

/** What a single selected node that has produced something can do. */
function NodeRow({ count, onExport }: { count: number; onExport: () => void }) {
  return (
    <button className={rowClass} onClick={onExport} type="button">
      <HugeiconsIcon aria-hidden icon={Download01Icon} size={14} />
      <span>Download {count === 1 ? "it" : `all ${count}`}</span>
    </button>
  );
}

/**
 * Sends a node's SVG to the desktop editor, where it is edited and saved back.
 *
 * The editor is named by the bridge rather than by this label: it opens
 * whatever VECTOR_APP points at, so a hardcoded "Affinity" is wrong for anyone
 * running Boxy SVG or Inkscape — and wrong quietly, because the button still
 * works.
 */
function EditorRow({ onOpen }: { onOpen: () => void }) {
  const editor = useVectorEditorName();
  return (
    <button className={rowClass} onClick={onOpen} type="button">
      <HugeiconsIcon aria-hidden icon={PenTool01Icon} size={14} />
      <span>Open in {editor}</span>
    </button>
  );
}

/** Traces a placed picture into vector art with the Recraft vectorizer. */
/**
 * Drops a proof sheet for this Brand node's mark onto the board you are on.
 *
 * The kit panel's button makes a board of its own, which is right when a
 * review is what you sat down to do. This is the other case: you are mid-work
 * with the mark already wired into something, and being sent elsewhere to look
 * at it is the interruption rather than the help.
 */
function ProofRow({ onProof }: { onProof: () => void }) {
  return (
    <button className={rowClass} onClick={onProof} type="button">
      <HugeiconsIcon aria-hidden icon={PenTool01Icon} size={14} />
      <span>Proof this mark</span>
    </button>
  );
}

/**
 * Saves whatever picture this item is showing.
 *
 * There was already a download for a Generate node's batch, and nothing at all
 * for a plain picture — a dropped reference, a photograph, a proof tile. Those
 * are most of what sits on a board, and the only way to get one back out was
 * to find it in blob storage.
 */
function SaveRow({ onSave }: { onSave: () => void }) {
  return (
    <button className={rowClass} onClick={onSave} type="button">
      <HugeiconsIcon aria-hidden icon={Download01Icon} size={14} />
      <span>Save this picture</span>
    </button>
  );
}

function VectorizeRow({ onVectorize }: { onVectorize: () => void }) {
  return (
    <button className={rowClass} onClick={onVectorize} type="button">
      <HugeiconsIcon aria-hidden icon={MagicWand01Icon} size={14} />
      <span>Vectorize</span>
    </button>
  );
}

/** The two ends of the stack, for an item buried (or lost) in the middle. */
function StackRows({
  onBringToFront,
  onSendToBack,
}: {
  onBringToFront: () => void;
  onSendToBack: () => void;
}) {
  return (
    <>
      <button className={rowClass} onClick={onBringToFront} type="button">
        <HugeiconsIcon aria-hidden icon={ArrowUp01Icon} size={14} />
        <span>Bring to front</span>
      </button>
      <button className={rowClass} onClick={onSendToBack} type="button">
        <HugeiconsIcon aria-hidden icon={ArrowDown01Icon} size={14} />
        <span>Send to back</span>
      </button>
    </>
  );
}

/** Sends the picture into a Canva design the admin can carry on editing. */
function CanvaRow({ onSend }: { onSend: () => void }) {
  return (
    <button className={rowClass} onClick={onSend} type="button">
      <HugeiconsIcon aria-hidden icon={Image01Icon} size={14} />
      <span>Send to Canva</span>
    </button>
  );
}

/**
 * The actions that only make sense for one picked item: hand over its results,
 * edit it in the desktop editor, vectorize it, or move it through the stack.
 *
 * Split out of MenuRows because each is its own boolean of conditions, and the
 * menu was heading past the complexity ceiling one row at a time.
 */
function SingleItemRows({
  items,
  onBringToFront,
  onExport,
  onOpenInAffinity,
  onProofMark,
  onSendToCanva,
  onSendToBack,
  onVectorize,
  onlyPicked,
}: {
  items: BoardItem[];
  onBringToFront: (itemId: string) => void;
  onExport: (itemId: string) => void;
  onOpenInAffinity?: (itemId: string) => void;
  /** Places a proof sheet for a Brand node's chosen mark on this board. */
  onProofMark?: (itemId: string) => void;
  onSendToCanva?: (item: BoardItem) => void;
  onSendToBack: (itemId: string) => void;
  onVectorize?: (itemId: string) => void;
  onlyPicked: BoardItem | null;
}) {
  // A single selected node that has produced something can hand over the whole
  // batch. More than one selected is a grouping gesture, not an export one.
  const madeCount = onlyPicked ? countResults(onlyPicked) : 0;
  // Any picture can go to the editor, not only a vector one. A raster is
  // wrapped on the way — see rasterAsSvg — so the round trip is unchanged and
  // the button stops hiding on almost everything a board makes.
  const pickedImage = onlyPicked
    ? Boolean(outputImageOf(onlyPicked, items))
    : false;

  // A placed picture — photo or reference — is a raster waiting to be traced.
  // The Recraft vectorizer needs a source, so a node with no image would have
  // nothing to offer it. An SVG is already vector art, so offering to trace it
  // is offering to fail.
  const placedImage =
    onlyPicked &&
    (onlyPicked.kind === "photo" || onlyPicked.kind === "reference") &&
    Boolean(onlyPicked.imageUrl) &&
    !isSvgUrl(onlyPicked.imageUrl);

  return (
    <>
      {onlyPicked && madeCount > 0 ? (
        <NodeRow count={madeCount} onExport={() => onExport(onlyPicked.id)} />
      ) : null}

      {onlyPicked && pickedImage && onOpenInAffinity ? (
        <EditorRow onOpen={() => onOpenInAffinity(onlyPicked.id)} />
      ) : null}

      {onlyPicked && pickedImage && madeCount === 0 ? (
        <SaveRow
          onSave={() =>
            void downloadImage(
              outputImageOf(onlyPicked, items) ?? "",
              onlyPicked.body ?? "image"
            )
          }
        />
      ) : null}

      {onlyPicked ? <PrintRow item={onlyPicked} rowClass={rowClass} /> : null}

      {onlyPicked?.nodeType === "brand" && onProofMark ? (
        <ProofRow onProof={() => onProofMark(onlyPicked.id)} />
      ) : null}

      {onlyPicked && placedImage && onVectorize ? (
        <VectorizeRow onVectorize={() => onVectorize(onlyPicked.id)} />
      ) : null}

      {onlyPicked && onSendToCanva && outputImageOf(onlyPicked, items) ? (
        <CanvaRow onSend={() => onSendToCanva(onlyPicked)} />
      ) : null}

      {onlyPicked && onlyPicked.kind !== "frame" ? (
        <StackRows
          onBringToFront={() => onBringToFront(onlyPicked.id)}
          onSendToBack={() => onSendToBack(onlyPicked.id)}
        />
      ) : null}
    </>
  );
}

/** What a selection can be turned into. */
function GroupRows({ count, onGroup }: { count: number; onGroup: () => void }) {
  return (
    <>
      <button className={rowClass} onClick={onGroup} type="button">
        <HugeiconsIcon aria-hidden icon={FrameIcon} size={14} />
        <span>
          Group {count === 1 ? "" : `${count} `}
          into a frame
        </span>
      </button>
      <p className="panel-row-note">
        Arrange them inside, then wire the frame into a Composite node.
      </p>
    </>
  );
}

/** The things a frame under the pointer can do. */
function FrameRows({
  canArrange,
  canGroup,
  count,
  onArrange,
  onCopy,
  onExport,
  onTrain,
}: {
  canArrange: boolean;
  canGroup: boolean;
  count: number;
  onArrange: () => void;
  onCopy: () => void;
  onExport: () => void;
  /** Absent on a board that cannot hand the frame to a trainer. */
  onTrain?: () => void;
}) {
  return (
    <>
      {canArrange ? (
        <button
          className={`${rowClass} ${canGroup ? "panel-row--divided" : ""}`}
          onClick={onArrange}
          type="button"
        >
          <HugeiconsIcon aria-hidden icon={GridIcon} size={14} />
          <span>Arrange {count} into a grid</span>
        </button>
      ) : null}
      <button
        className={`${rowClass} ${canGroup || canArrange ? "panel-row--divided" : ""}`}
        onClick={onExport}
        type="button"
      >
        <HugeiconsIcon aria-hidden icon={Download01Icon} size={14} />
        <span>Download {count === 1 ? "it" : `all ${count}`}</span>
      </button>
      <button
        className={`${rowClass} panel-row--divided`}
        onClick={onCopy}
        type="button"
      >
        <HugeiconsIcon aria-hidden icon={CopyIcon} size={14} />
        <span>Copy frame to new board</span>
      </button>
      {/* Last, and divided: it is the only row here that hands work to a
          third party, so it should not sit next to the local ones. */}
      {onTrain ? (
        <button
          className={`${rowClass} panel-row--divided`}
          onClick={onTrain}
          type="button"
        >
          <HugeiconsIcon aria-hidden icon={SparklesIcon} size={14} />
          <span>Train a model on this frame</span>
        </button>
      ) : null}
    </>
  );
}

/* The shared menu row — see .panel-row in boardChrome.css. Kept as a constant
   because fifteen call sites here pass it down as a prop. */
const rowClass = "panel-row";

/** Everything on offer before a name is being typed. */
export function MenuRows({
  items,
  menu,
  onArrange,
  onBringToFront,
  onCollect,
  onCopy,
  onDismiss,
  onExport,
  onGroup,
  onSaveElement,
  onSaveRecipe,
  onOpenInAffinity,
  onProofMark,
  onSendToCanva,
  onSendToBack,
  onTools,
  onVectorize,
  wires,
}: {
  items: BoardItem[];
  menu: CanvasMenuTarget;
  onArrange: (itemId: string) => void;
  onBringToFront: (itemId: string) => void;
  /** Opens the collection panel on the pictures the selection can hand over. */
  onCollect: (urls: string[]) => void;
  onCopy: (frame: BoardItem) => void;
  /** Closes the menu, for a row whose work outlives it. */
  onDismiss: () => void;
  onExport: (itemId: string) => void;
  onGroup: (items: BoardItem[]) => void;
  onSaveElement: (items: BoardItem[]) => void;
  /** Absent on a board that cannot save one — a visitor, or a read-only view. */
  onSaveRecipe?: (items: BoardItem[]) => void;
  onOpenInAffinity?: (itemId: string) => void;
  /** Places a proof sheet for a Brand node's chosen mark on this board. */
  onProofMark?: (itemId: string) => void;
  onSendToCanva?: (item: BoardItem) => void;
  onSendToBack: (itemId: string) => void;
  /** Opens the tool picker on the one selected item. Absent, the row is too. */
  onTools?: (item: BoardItem) => void;
  onVectorize?: (itemId: string) => void;
  wires: BoardWire[];
}) {
  const { frame, selection } = menu;
  // From the context rather than a prop: see FrameOpenContext.
  const { trainOnFrame } = useFrameActions();
  const canGroup = selection.length > 0;
  const summary = frame ? frameSummary(frame, items, wires) : null;

  // A single selected node that has produced something can hand over the whole
  // batch. More than one selected is a grouping gesture, not an export one.
  const onlyPicked = selection.length === 1 ? selection[0] : null;

  // Every picture the selection can hand over, resolved the way a wire would
  // resolve it — so selecting a frame offers the pictures sitting on it, and
  // selecting a node offers the version chosen on it, rather than nothing.
  const pictures = selection.flatMap((item) =>
    outputImagesOf(item, { items, wires })
  );

  // What a recipe would actually hold. Counted rather than assumed from the
  // selection length: selecting a node and the reference feeding it is two
  // things, and only one of them is a step in the way of working.
  const nodes = selection.filter((item) => item.kind === "op");

  return (
    <>
      {/* First, because it is the only row that leads anywhere rather than
          doing something — and because the tools are what the item *is* for. */}
      {onlyPicked && onTools && hasTools(onlyPicked) ? (
        <ToolsRow className={rowClass} onOpen={() => onTools(onlyPicked)} />
      ) : null}

      <SingleItemRows
        items={items}
        onBringToFront={onBringToFront}
        onExport={onExport}
        onlyPicked={onlyPicked}
        onOpenInAffinity={onOpenInAffinity}
        onProofMark={onProofMark}
        onSendToBack={onSendToBack}
        onSendToCanva={onSendToCanva}
        onVectorize={onVectorize}
      />

      {canGroup ? (
        <GroupRows
          count={selection.length}
          onGroup={() => onGroup(selection)}
        />
      ) : null}

      {/* Offered only when the selection holds something that can run. A
          recipe is a way of working, so a selection of pinned photographs has
          no way of working in it to keep. */}
      {onSaveRecipe && nodes.length > 0 ? (
        <button
          className={`${rowClass} panel-row--divided`}
          onClick={() => onSaveRecipe(selection)}
          type="button"
        >
          <HugeiconsIcon aria-hidden icon={RepeatIcon} size={14} />
          <span>
            Save {nodes.length === 1 ? "it" : `${nodes.length} nodes`} as a
            recipe
          </span>
        </button>
      ) : null}

      {/* Offered only when there is something to keep. An element is its
          pictures, so a selection of notes and wires has nothing to save. */}
      {pictures.length > 0 ? (
        <button
          className={`${rowClass} panel-row--divided`}
          onClick={() => onSaveElement(selection)}
          type="button"
        >
          <HugeiconsIcon aria-hidden icon={Album02Icon} size={14} />
          <span>
            Save {pictures.length === 1 ? "it" : `${pictures.length}`} as an
            element
          </span>
        </button>
      ) : null}

      {pictures.length > 0 ? (
        <CollectionRow
          className={rowClass}
          count={pictures.length}
          onOpen={() => onCollect(pictures)}
        />
      ) : null}

      {frame ? (
        <FrameRows
          canArrange={(summary?.count ?? 0) > 1}
          canGroup={canGroup}
          count={summary?.count ?? 0}
          onArrange={() => onArrange(frame.id)}
          onCopy={() => onCopy(frame)}
          onExport={() => onExport(frame.id)}
          onTrain={
            trainOnFrame
              ? () => {
                  trainOnFrame(frame.id);
                  onDismiss();
                }
              : undefined
          }
        />
      ) : null}
    </>
  );
}
