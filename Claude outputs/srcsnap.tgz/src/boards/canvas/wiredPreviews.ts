import type { BoardItem, BoardWire } from "../../types";
import {
  iteratedTextOf,
  outputImagesOf,
  outputListOf,
  outputTextOf,
} from "../itemOutput";
import { itemsFromWire } from "../listItems";
import { runPlanFor } from "./runPlan";

/**
 * What a node is about to send, shown before it is run.
 *
 * Lifted out of BoardCanvas.tsx, which had no room left to grow. These four
 * read the graph rather than change it, and they exist for one reason: seeing
 * "3 prompts" and what they say is the only way to know a batch is set up right
 * before paying for it.
 *
 * The graph arrives as an argument rather than being closed over, which is what
 * makes them testable without a canvas — and what makes it obvious that they
 * only ever read.
 */

export interface Graph {
  items: BoardItem[];
  wires: BoardWire[];
}

/**
 * What a node that composes text will send, read before it runs. Combine
 * answers with one string, Iterate with one per value — seeing "3 prompts"
 * and what they say is the only way to know a batch is set up right.
 */
/** The pictures a Batch node holds. Only that node: resolving every image
 * behind every node on every render walks the graph once per node. */
export const previewImagesFor = (
  item: BoardItem,
  graph: Graph
): string[] | undefined =>
  item.nodeType === "batch" ? outputImagesOf(item, graph) : undefined;

export const previewTextFor = (
  item: BoardItem,
  graph: Graph
): string | null => {
  if (item.nodeType === "join" || item.nodeType === "palette") {
    return outputTextOf(item, graph);
  }
  if (item.nodeType !== "iterate") {
    return null;
  }
  const prompts = iteratedTextOf(item, graph);
  if (prompts.length === 0) {
    return null;
  }
  return prompts.map((text, index) => `${index + 1}. ${text}`).join("\n");
};

/**
 * The words arriving on an item's prompt input, so the node can show them.
 *
 * Resolved here because only the canvas holds the graph.wires; the node itself
 * knows nothing about what feeds it.
 */
export const wiredTextFor = (itemId: string, graph: Graph): string | null => {
  // Every wire on the prompt port, kept apart: each contributes a part of
  // each run, and a wire carrying several values makes several runs. Mirrors
  // jobsFor, so what the node shows is what the node will send.
  const perWire = graph.wires
    .filter((w) => w.targetItemId === itemId && w.targetPort === "prompt")
    .map((w) => graph.items.find((i) => i.id === w.sourceItemId))
    .map((source) => outputListOf(source ?? null, graph))
    .map((list) => list.filter((text) => text.trim()))
    .filter((list) => list.length > 0);

  if (perWire.length === 0) {
    return null;
  }
  const rows = Math.max(...perWire.map((list) => list.length));
  const prompts = Array.from({ length: rows }, (_, row) =>
    perWire.map((list) => list[row % list.length] ?? "").join(", ")
  );
  return rows === 1
    ? (prompts[0] ?? null)
    : prompts.map((text, index) => `${index + 1}. ${text}`).join("\n");
};

/**
 * The rows arriving on a List node's Fill input, in wire order.
 *
 * Flattened, because a single wire usually carries the whole list: an Iterate
 * node hands over fifty prompts as fifty entries, and a Prompt node hands over
 * one string that may itself be fifty lines. Both mean fifty rows.
 *
 * Answers only for a List node, guarding inside like previewImagesFor rather
 * than at the call site: resolving every upstream behind every node on every
 * render walks the graph once per node, and the guard belongs with the reason
 * for it.
 */
export const wiredItemsFor = (
  item: BoardItem,
  graph: Graph
): string[] | undefined => {
  if (item.nodeType !== "list") {
    return;
  }
  return itemsFromWire(
    graph.wires
      .filter((w) => w.targetItemId === item.id && w.targetPort === "text")
      .flatMap((w) =>
        outputListOf(
          graph.items.find((i) => i.id === w.sourceItemId) ?? null,
          graph
        )
      )
  );
};

/**
 * Every picture arriving on an item's image input, in wire order.
 *
 * Through outputImagesOf, which is the *only* client-side resolver that expands
 * a Batch node and a frame the way the server's outputsOf does. outputListOf,
 * which this reached for first, knows about Iterate, List and Palette and
 * nothing about pictures: a Batch of twenty-two wired into a halftone resolved
 * to one image here while the server resolved twenty-two and asked for
 * twenty-two variations. Twenty-one of them had nothing to hand back and the
 * whole run came home empty.
 *
 * The two sides must agree on the count or the run asks for a picture the
 * browser never drew. That is the invariant; this function exists to hold it.
 */
/**
 * How many pictures a node is about to work through.
 *
 * Asked only of the node that draws them itself, the same guard-inside shape
 * previewImagesFor and wiredItemsFor use: resolving every upstream behind every
 * node on every render walks the graph once per node.
 */
export const wiredImageCountFor = (
  item: BoardItem,
  graph: Graph
): number | undefined =>
  item.nodeType === "standard"
    ? wiredImagesFor(item.id, graph).length
    : undefined;

/**
 * Every picture arriving on one named input, in wire order.
 *
 * The finishing nodes take their pictures on ports of their own — a Cover's
 * `art`, a Print wrap's `front` and `back`, a Mockup's `cover` and `wrap` —
 * so "the image port" is not a fixed name. This is the resolver with the port
 * as an argument; wiredImagesFor is it applied to "image".
 */
export const wiredImagesOnPort = (
  itemId: string,
  port: string,
  graph: Graph
): string[] =>
  graph.wires
    .filter((w) => w.targetItemId === itemId && w.targetPort === port)
    .flatMap((w) =>
      outputImagesOf(
        graph.items.find((i) => i.id === w.sourceItemId) ?? null,
        graph
      )
    )
    .filter((url) => Boolean(url?.trim()));

export const wiredImageOnPort = (
  itemId: string,
  port: string,
  graph: Graph
): string | null => wiredImagesOnPort(itemId, port, graph)[0] ?? null;

/**
 * The text arriving on one named input, lines joined.
 *
 * Unlike wiredTextFor this does not cross wires into runs: a Cover's `words`
 * or a wrap's `copy` is one block of text, and a Note with three lines in it
 * is three lines of one thing, not three prompts.
 */
export const wiredTextOnPort = (
  itemId: string,
  port: string,
  graph: Graph
): string | null => {
  const lines = graph.wires
    .filter((w) => w.targetItemId === itemId && w.targetPort === port)
    .map((w) => graph.items.find((i) => i.id === w.sourceItemId) ?? null)
    .flatMap((source) => outputListOf(source, graph))
    .filter((text) => text.trim());
  return lines.length > 0 ? lines.join("\n") : null;
};

export const wiredImagesFor = (itemId: string, graph: Graph): string[] =>
  wiredImagesOnPort(itemId, "image", graph);

/**
 * The picture feeding an item's image input, for the kinds that render one
 * themselves rather than being run on the server.
 *
 * A shader restyles its input live in the browser, so the URL has to reach
 * the component; nothing is written to the item, which keeps the wire the
 * single source of truth for what is being shown.
 */
export const wiredImageFor = (itemId: string, graph: Graph): string | null =>
  /*
   * The first of everything wired in, through the resolver that knows about
   * batches.
   *
   * It used to read outputImageOf directly, which is given the items and not
   * the wires — so it cannot see what feeds a Batch node, and a Batch holds
   * nothing of its own to fall back on. It has no capability and never runs, so
   * reading its `result` answers null. A halftone fed by a batch therefore drew
   * nothing and said "wire a picture into this node" with a wire plainly
   * attached to it.
   *
   * The same resolver wiredImagesFor uses, taking one instead of all, so the
   * preview and the render can never disagree about what is feeding a node.
   */
  wiredImagesFor(itemId, graph)[0] ?? null;

/**
 * Everything the six resolvers above answer, for every item, worked out once.
 *
 * They were being called inside the item loop — six graph walks per item per
 * render, each recursing through whatever feeds it. On a board of fifty that is
 * three hundred walks, and BoardCanvas re-renders on every pointer move: a
 * drag, a marquee, a selection change, a guide appearing. The cost is quadratic
 * in the board and it was being paid at pointer rate.
 *
 * None of it depends on the pointer. Every one of these is a function of the
 * items and the wires alone, so the whole table is computed when the graph
 * changes and read by address the rest of the time.
 */
export interface WiredPreview {
  imageCount?: number;
  imageUrl: string | null;
  outputText: string | null;
  previewImages?: string[];
  /**
   * Generations one press of Run will buy, for the node that buys them.
   *
   * Undefined for every other kind, which is how the node knows not to show a
   * number: a Composite renders in the browser and costs nothing, and a line
   * saying "9 runs" over it would be a lie about money.
   */
  runs?: number;
  wiredItems?: string[];
  wiredPrompt: string | null;
}

/**
 * What this node will spend, for the one node that spends.
 *
 * Guarded inside like the resolvers above, and narrowed to Generate on
 * purpose: it is the node with the multiplying inputs, and the only one where
 * the number is ever a surprise.
 */
const runCountFor = (item: BoardItem, graph: Graph): number | undefined =>
  item.nodeType === "generate" ? runPlanFor(item, graph).runs : undefined;

export const resolveWired = (graph: Graph): Map<string, WiredPreview> =>
  new Map(
    graph.items.map((item) => [
      item.id,
      {
        imageCount: wiredImageCountFor(item, graph),
        imageUrl: wiredImageFor(item.id, graph),
        outputText: previewTextFor(item, graph),
        previewImages: previewImagesFor(item, graph),
        runs: runCountFor(item, graph),
        wiredItems: wiredItemsFor(item, graph),
        wiredPrompt: wiredTextFor(item.id, graph),
      },
    ])
  );

/**
 * What an item that is not in the table would answer.
 *
 * So a caller reads `preview.imageUrl` rather than
 * `wired.get(id)?.imageUrl ?? null` six times over — five nullish fallbacks in
 * a render loop is five branches, and it pushed the loop past the complexity
 * ceiling for no gain in safety.
 */
export const NO_PREVIEW: WiredPreview = {
  imageUrl: null,
  outputText: null,
  wiredPrompt: null,
};
